// swift-tools-version:5.3
// Leave blank. This is only here so that Xcode doesn't display it.

import PackageDescription

let package = Package(
    name: "Examples",
    products: [],
    targets: []
)
